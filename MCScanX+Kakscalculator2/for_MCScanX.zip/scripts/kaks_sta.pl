my $prefix=$ARGV[0];
my $output="$prefix.kakssta.txt";
open OUT,">>","$output";
print OUT "gene\tka\tks\tkaks\n";
my @files=glob("*kaks");
foreach my $file (@files) {
	open IN,"<","$file";
	while (<IN>) {
		next if /^Sequence/;
		chomp;
		my ($gene,$ka,$ks,$kaks)=(split/\s+/)[0,2,3,4];
		print OUT "$gene\t$ka\t$ks\t$kaks\n";
	}
}
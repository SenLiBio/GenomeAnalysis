use 5.010;
use strict;
use autodie;
use warnings;

die "USAGE: perl gff_to_MCScanXgff.pl [two-letter species contraction] [INPUTFILE] [OUTPUTFILE] \n" if (@ARGV < 1);

my $species_name_contraction=$ARGV[0];

open IN,"<$ARGV[1]" || die "Cannot open $ARGV[1]:$!";
open OUT,">$ARGV[2]" || die "Cannot open $ARGV[2]:$!";

while (<IN>) {
	if (/mRNA/) {
		chomp;
		my $line=$_;
		my ($sca,$sta,$end,$info)=(split/\s+/,$line)[0,3,4,8];
		$sca=~/(?<sca_num>\d+$)/;
		my $sca_num=$+{sca_num};
		$info=~/ID=(?<gene_name>\S+?);/;
		print OUT "$species_name_contraction$sca_num\t$+{gene_name}\t$sta\t$end\n";
	} else {
		next;
	}
}

close IN;
close OUT;
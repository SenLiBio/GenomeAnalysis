die "USAGE:perl interspecies_genes_for_each_species.pl [INPUTFILE] \n" if (@ARGV < 1); 
use strict;
my @species1_genes;
my @species2_genes;

while (<>) {
	next if /^#/;
	chomp;
	$_=~s/^\s*\d+\-\s*\d+:\s*//;
	my ($gene1,$gene2)=(split/\s+/,$_)[0,1];
	push @species1_genes,$gene1;
	push @species2_genes,$gene2;
}

my (%num_of_species1_gene,%num_of_species2_gene);
map {$num_of_species1_gene{$_}++} @species1_genes;
map {$num_of_species2_gene{$_}++} @species2_genes;

my $num_of_species1_gene=keys %num_of_species1_gene;
my $num_of_species2_gene=keys %num_of_species2_gene;
print "num_of_species1_gene:$num_of_species1_gene\nnum_of_species2_gene:$num_of_species2_gene\n";
use warnings;
use strict;
my $pepdir=shift;
my @mafftfiles=<$pepdir/*>;
my $cdsdir=shift;
my $outdir=shift;
system ("mkdir $outdir");
my $output_sh=shift;
open(O,">$output_sh");

my $pal2alnpath="/data/users/lisen/software/pal2nal.v14";
foreach my $pepfile (@mafftfiles){
    $pepfile=~/mafft(\d+_\d+)/;
    my $sign=$1;
        my $cds="$sign.cds";
    print O "perl $pal2alnpath/pal2nal.pl $pepfile $cdsdir/$cds -nogap -output fasta >$outdir/pal2aln$sign\n";
}
close O;
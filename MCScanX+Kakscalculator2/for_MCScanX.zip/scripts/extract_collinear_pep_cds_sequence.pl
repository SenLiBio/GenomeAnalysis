use strict;
use warnings;
use Bio::SeqIO;
use autodie;

die "Usage:perl $0 [CDS file] [PEP file] [COLLINEAR file] [CDS outdir] [PEP outdir]" if @ARGV<4;

my $cds=shift;
my $pep=shift;
my $col=shift;
my $cdsdir=shift;
my $pepdir=shift;
system ("mkdir $cdsdir");
system ("mkdir $pepdir");


my %pep;
my $pep=Bio::SeqIO->new (-file=>"$pep",-format=>"fasta");
while (my $seq=$pep->next_seq) {
	my $id=$seq->id;
	my $sequence=$seq->seq;
	$pep{$id}=$sequence;
}
print "$pep has done\n";

my %cds;
my $cds=Bio::SeqIO->new (-file=>"$cds",-format=>"fasta");
while (my $seq=$cds->next_seq) {
	my $id=$seq->id;
	my $sequence=$seq->seq;
	$cds{$id}=$sequence;
}
print "$cds has done\n";

open COL,"<","$col";
while (<COL>) {
	next if /^#/;
	$_=~/^ *(?<block>\d+)\- *(?<code>\d+):\s+(?<gene1>.*?)\s+(?<gene2>.*?)\s+/;
	my $outputpep="$pepdir/$+{block}_$+{code}.pep";
	my $outputcds="$cdsdir/$+{block}_$+{code}.cds";
	open PEPOUT,">","$outputpep";
	open CDSOUT,">","$outputcds";
	print PEPOUT ">$+{gene1}\n$pep{$+{gene1}}\n>$+{gene2}\n$pep{$+{gene2}}\n";
	print CDSOUT ">$+{gene1}\n$cds{$+{gene1}}\n>$+{gene2}\n$cds{$+{gene2}}\n";
	close PEPOUT;
	close CDSOUT;
}
close COL;
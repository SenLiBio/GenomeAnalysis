use 5.010;
use autodie;
use strict;

die "USAGE: perl extract_interspecies_blocks.pl [INPUTFILE] [OUTPUTFILE] \n" if (@ARGV < 1);


open IN,"<$ARGV[0]" || die "Cannot open $ARGV[0]:$!";
open OUT,">$ARGV[1]" || die "Cannot open $ARGV[1]:$!";

my @inputlines=<IN>;
for (1..8) {
	my $line=shift @inputlines;
	print OUT "$line";
}

shift @inputlines;
my $line=shift @inputlines;
$line=~/(\d+$)/;
my $num_of_all_genes=$1;
shift @inputlines;


my ($judge,%interspecies_block_name);
my $num_of_interspecies_genes=0;
my $num_of_interspecies_blocks=-1;
my $tsv;
my $num_of_gene_pairs_in_the_block;
my ($species1,$species2);
my @collinear_genes;

foreach my $line (@inputlines) {
	if ($line =~ m/^##/) {
		$line=~m/(\w{2})\d+\&(\w{2})\d+/;
		$species1=$1;
		$species2=$2;
		if ($species1 ne $species2) {
			$judge=1;
			$num_of_interspecies_blocks++;
			$line=~s/Alignment \d+/Alignment $num_of_interspecies_blocks/;
			$interspecies_block_name{$num_of_interspecies_blocks}=$line;
			$num_of_gene_pairs_in_the_block=0;
			$tsv->[$num_of_interspecies_blocks][0]=$line;
		} else {
			$judge=0;
		}
	} else {
		if ($judge==0) {
			next;
		} else {
			$line=~/^ *\d+\- *\d+:\s+(?<gene1>.*?)\s+(?<gene2>.*?)\s+/;
			push @collinear_genes,$+{gene1},$+{gene2};
			$num_of_gene_pairs_in_the_block++;
			$line=~s/^ *\d+/ $num_of_interspecies_blocks/;
			$tsv->[$num_of_interspecies_blocks][$num_of_gene_pairs_in_the_block]=$line;
		}
	}
}

close IN;

my %num;
map {$num{$_}++} @collinear_genes;
@collinear_genes=keys %num;
$num_of_interspecies_genes=@collinear_genes;

my $percentage_of_interspecies_genes=100*$num_of_interspecies_genes/$num_of_all_genes;
print OUT "# Number of collinear genes: $num_of_interspecies_genes, Percentage: ";
printf OUT "%5.2f\n", $percentage_of_interspecies_genes;
print OUT "# Number of all genes: $num_of_all_genes\n##########################################\n";



foreach my $num_of_block (0..$num_of_interspecies_blocks) {
	foreach my $num_of_gene_pairs_in_the_block (0..@{$tsv->[$num_of_block]}) {
		print OUT "$tsv->[$num_of_block][$num_of_gene_pairs_in_the_block]";
	}
}



close OUT;
use warnings;
use strict;

die "Usage: perl $0 [PEP dir] [SH output] [MAFFT outdir]" if @ARGV<3;

my $homolog_dir=shift;
my @files=<$homolog_dir/*>;
my $output_sh=shift;
open (O,">$output_sh");

my $outdir=shift;
system("mkdir $outdir");
foreach my $file (@files){
    $file=~/^.*\/(.*)\.pep/;
        my $sign=$1;
    my $outfile="$outdir/mafft$sign";
    print O "mafft --maxiterate 1000 --localpair $file >$outfile\n";
}
close O;
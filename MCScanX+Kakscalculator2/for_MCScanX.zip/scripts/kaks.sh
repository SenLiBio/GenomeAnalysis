perl ../scripts/extract_collinear_pep_cds_sequence.pl cds pep collinearity cdsdir pepdir &&
perl ../scripts/create_mafft_sh.pl pepdir mafft.sh mafftoutdir
bash mafft.sh &&
perl ../scripts/create_pal2nal.pl mafftoutdir cdsdir pal2naloutdir pal2nal.sh &&
bash pal2nal.sh &&
cd pal2naloutdir &&
mkdir axts &&
mkdir fas &&
perl ../../scripts/fa2axt.pl &&
mv *axt axts &&
mv pal* fas &&
cd axts &&
perl ../../../scripts/kakscal.pl &&
mkdir kakss &&
mkdir axts &&
mv *axt axts &&
mv *kaks kakss &&
cd kakss &&
perl ../../../../scripts/kaks_sta.pl &&
mv kaks_sta.txt ../../../../
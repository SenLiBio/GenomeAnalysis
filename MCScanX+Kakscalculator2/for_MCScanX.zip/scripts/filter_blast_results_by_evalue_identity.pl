use 5.010;
use strict;
use autodie;
use warnings;

die "USAGE: perl filter_blast_results_by_evalue_identity.pl [identity] [e-value] [INPUTFILE] [OUTPUTFILE] \n" if (@ARGV < 1);

my $identity_threshold=$ARGV[0];
my $evalue_threshold=$ARGV[1];
open IN,"<$ARGV[2]" || die "Cannot open $ARGV[2]:$!";
open OUT,">$ARGV[3]" || die "Cannot open $ARGV[3]:$!";

while (<IN>) {
	my $line=$_;
	my ($identity,$evalue)=(split/\s+/,$line) [2,10];
	next if ($identity <= $identity_threshold || $evalue >= $evalue_threshold);
	print OUT "$line";
}
close IN;
close OUT;
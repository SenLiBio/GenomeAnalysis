# teclass.sh
#USAGE: sh this_script custom
#custom must be 123wxyz format (3num4letters)
mkdir 0out_rmd 1known_rmd 2unknown_rmd 3out_tecls 4transOut_tecls 5ultRslt
ln -s ../$1-families.fa 0out_rmd/
for i in ./0out_rmd/*.fa;do echo $i;perl seperate_denoPrdcTEconsn.pl $i;done 

cd 2unknown_rmd/
for i in *.fa; do numbAbbr=`echo $i|sed 's/.*\([0-9]\{3\}....\).*\.fa/\1/'`; TEclassTest -o ../3out_tecls/$numbAbbr $i>outstd.teclass_$numbAbbr 2>errstd.teclass_$numbAbbr; done

cd ../

for i in 3out_tecls/*/*-families.fa.lib;do echo $i;perl teclass_title_transition.pl $i;done

for i in ./1known_rmd/*.fa; do file=`echo $i|sed 's/.*\([0-9]\{3\}.*\.fa\)/\1/'`; cat ./1known_rmd/$file ./4transOut_tecls/$file >./5ultRslt/$file; done

#for fm in 5ultRslt/*-families.fa; do nw=`echo $fm|sed 's/.*[0-9]\{3\}\(....\).*ies\.fa/\1/'`;echo $nw; sed -i "s/^>rnd-/>$nw/" $fm;sed -i 's/family-/fmly/' $fm;done
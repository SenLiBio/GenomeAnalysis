#USAGGE: sh this_script custom genome.fasta
#the parallel version of repeatm.sh 
#custom must be 123wxyz format (3num4letters) 
BuildDatabase -name $1 -engine ncbi $2 >./outstd_BD_$1 2>./errstd_BD_$1
RepeatModeler engine ncbi -pa 4 -database $1 >./outstd_RMd_$1 2>./errstd_RMd_$1
mkdir ./teclass
cd ./teclass
sh ./my_script/teclass.sh  $1
cd ..
ln -s ./teclass/5ultRslt/$1-families.fa $1-families_tecls.fa
mkdir ./customLib_defSpd_$1
RepeatMasker -html -gff -x -poly -pa 4 -dir ./customLib_defSpd_$1 -lib ./"$1-families_tecls.fa" $2 >./outstd_RMs_$1 2>./errstd_RMs_$1
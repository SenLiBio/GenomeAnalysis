# seperate_denoPrdcTEconsn.pl
#!/usr/bin/perl -w

#used to seperate known and unknown TE consensus sequence 
#output of RepeatModeler.
#two directoried must exist when run this script!!!!!!!!!
#they are 1known_rmd & 2unknown_rmd 

#USAGE: perl this_script file.fasta

use strict;
my %id2seq=&hash_fasta($ARGV[0]);
$ARGV[0]=~m/\d{3}\w{4}.*-families\.fa/;
open KNN, ">1known_rmd/$&" or die "$!";
open UNKNN, ">2unknown_rmd/$&" or die "$!";
foreach(sort{$a cmp$b}keys%id2seq){
        if(/#Unknown/){
                print UNKNN ">$_"."$id2seq{$_}";
        }else{
                print KNN ">$_"."$id2seq{$_}";
        }
}

sub hash_fasta{#scaffold id to sequence hash generator
        open FA, "$_[0]" or die "$!";
        my %fa_hash=(); 
        my $id=""; 
        my @ids=();     
        while (<FA>){
                if (/^>/){
                        s/^>//;
                        my@_1=split "\\s+", $_;
                        #$id=$_1[0];
                        $id=$_;
                        push @ids, $_1[0];
                }else{
                        #s/\s+$//g;
                        $fa_hash{$id}.=$_;
                }
        }close FA;
        my @dup=grep{$_{$_}++}@ids; %_=();
        die "there are duplicated sequence ID(@dup) in $_[0] file" if @dup>0;   
        %fa_hash;
}
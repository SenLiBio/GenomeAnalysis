# teclass_title_transition.pl
#!/usr/bin/perl -w
#used to trans id line of teclass out file.
#Unknown will be substibuted to proper 
#TE type(one of 'DNA LINE LTR or SINE') if classification done
#make sure directory 4transOut_tecls exist, see line 14 which is
#'open OUT, ">./4transOut_tecls/$nfn";'

#USAGE: perl this_script TEclass_out.lib 
use strict;
my@te=qw/DNA LINE LTR SINE/;
open TECLSLIB, "<$ARGV[0]"or die "$!";
$ARGV[0]=~m/.+\/(\d{3}\w{4}.*?\.fa)\.lib/;
my$nfn=$1;#new file name
open OUT, ">./4transOut_tecls/$nfn";
my$sum=0;
my%te_counter=();
while(<TECLSLIB>){
        my $new_idline='';
        my $tecls='';
        if(m/(.+?)\|TEclass result: (.+?)\|/){
                $new_idline=$1;
                $tecls=$2;
                if($tecls~~@te){
                        $new_idline=~s/#Unknown/#$tecls/;
                        print OUT "$new_idline\n";
                }else{print OUT "$new_idline\n";
                }
        }else{print OUT $_;
        }
}
close OUT;
close TECLSLIB;